This file contains exta information about this project.

Created by: Gregor Boltz
Date created: 11.2021
Created for: Webcoding 1292 Oblig 3

Link to live website: https://folk.ntnu.no/gregorbo/project-healthy